<?php $__env->startSection('content'); ?>
    <main id="main-content" class="usa-prose grid-container tracking-container">

        <section class="track-order">
            <table id="myTable" class="display">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User Id</th>
                        <th>Complainant Name</th>
                        <th>Complainant Business</th>
                        <th>Complainant Phone</th>
                        <th>Complainant Email</th>
                        <th>Victim Name</th>
                        <th>Victim Business</th>
                        <th>Victim Email</th>
                        <th>Victim Phone</th>
                        <th>Victim Country</th>
                        <th>Victim City</th>
                        <th>Victim Sector</th>
                        <th>Money Sent</th>
                        <th>Reported Loss</th>
                        <th>Incident Description</th>
                        <th>Law Enforcement</th>
                        <th>Witnesses</th>
                        <th>Digital Signature</th>
                        <th>Complaint Session</th>
                        <th>Created At</th>
                        <th>Complaint Update</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($c->user_id); ?></td>
                            <td><?php echo e($c->complainant_name ?? '-'); ?></td>
                            <td><?php echo e($c->complainant_business_name ?? '-'); ?></td>
                            <td><?php echo e($c->complainant_phone ?? '-'); ?></td>
                            <td><?php echo e($c->complainant_email ?? '-'); ?></td>
                            <td><?php echo e($c->victim_name ?? '-'); ?></td>
                            <td><?php echo e($c->victim_business_name ?? '-'); ?></td>
                            <td><?php echo e($c->victim_email ?? '-'); ?></td>
                            <td><?php echo e($c->victim_phone ?? '-'); ?></td>
                            <td><?php echo e($c->victim_country ?? '-'); ?></td>
                            <td><?php echo e($c->victim_city ?? '-'); ?></td>
                            <td><?php echo e($c->victim_sector ?? '-'); ?></td>
                            <td><?php echo e($c->money_sent ? 'Yes' : 'No'); ?></td>
                            <td><?php echo e($c->reported_loss ?? '-'); ?></td>
                            <td><?php echo e(Str::limit($c->incident_description, 60) ?? '-'); ?></td>
                            <td><?php echo e($c->law_enforcement ?? '-'); ?></td>
                            <td><?php echo e($c->witnesses ?? '-'); ?></td>
                            <td><?php echo e($c->digital_signature ?? '-'); ?></td>
                            <td><?php echo e($c->complaint_session ?? '-'); ?></td>
                            <td><?php echo e($c->created_at->format('Y-m-d H:i')); ?></td>
                            <td>
                                <?php if($c->complaint_update): ?>
                                    <span class="badge bg-success-green">Done</span>
                                <?php else: ?>
                                    <span class="badge bg-danger-red">Pending</span>

                                    <?php if(Auth::user()->role == 1): ?>
                                        <form action="<?php echo e(route('complaint.approve', $c->id)); ?>" method="POST"
                                            style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button type="submit" class="btn btn-sm bg-success-green">Approve</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ic3.gov\resources\views/track-order.blade.php ENDPATH**/ ?>