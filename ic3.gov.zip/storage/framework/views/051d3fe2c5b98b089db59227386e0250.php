 <ul>
     <li>
         <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
     </li>

     <li>
         <a href="<?php echo e(route('user.profile')); ?>">Profile</a>
     </li>
     <?php if(Auth::user()->role == '1'): ?>
         <li>
             <a href="<?php echo e(route('admin.contact')); ?>">User Contacts</a>
         </li>
     <?php endif; ?>
     <li>
         <form action="<?php echo e(route('logout')); ?>" method="POST">
             <?php echo csrf_field(); ?>
             <button class="btn btn-danger">Logout</button>
         </form>
     </li>
 </ul>
<?php /**PATH C:\laragon\www\ic3.gov\resources\views/auth/include/sidebar.blade.php ENDPATH**/ ?>