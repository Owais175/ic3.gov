<?php $__env->startSection('content'); ?>
    <main id="main-content" class="usa-prose grid-container dashborad-styling">

        <section class="user-profile">
            <div class="main-dashborad-flex">
                <div class="sidebar-user-profile">
                    <?php echo $__env->make('auth.include.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="dashborad-content">
                    <div class="content-dashborad-pg">
                        <h1>Welcome <?php echo e(Auth::user()->name); ?></h1>
                        <p> You are successfully logged in to your account. Explore your dashboard to manage your profile
                            and
                            activities.
                        </p>
                    </div>
                </div>
            </div>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Welcome Back!',
            text: "<?php echo e(session('success')); ?>",
            background: '#fefefe',
            color: '#333',
            showConfirmButton: false,
            timer: 2500,
            backdrop: `
    rgba(0,0,123,0.2)
    url("/images/nyan-cat.gif")
    left top
    no-repeat
  `
        });
    </script>
<?php endif; ?>

<?php echo $__env->make('front.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ic3.gov\resources\views/dashboard.blade.php ENDPATH**/ ?>